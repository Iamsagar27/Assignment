const express = require('express');

const app = express();

const path = require('path');

const bodyParser = require('body-parser');

var MongoClient = require('mongodb').MongoClient
var db;

const url = "mongodb://localhost:27017";

//Establish Connection
MongoClient.connect(url, function (err, database) {
   if (err) 
   	throw err
   else
   {
	db = database.db('mydb');;
	console.log('Connected to MongoDB');
   }
 });

const PORT = 3000;

app.listen(PORT, () => {
    console.log (`Server listening at port ${PORT}`);
});

app.use(bodyParser.json());

app.get("/",(req,res) => {
    res.sendFile(path.join(__dirname,"/index.html")); // Send HTML File to Client
});

// JSON Data retrieve from HTML file
app.post("/",(req,res) => {
    // Insert the JSON data into Mongodb
    db.collection('person').insert(req.body, function (err, result) {
        if (err)
           res.send('Error occur while inserting');
        else
          res.send('Data inserted successfully');

        
    });
});
function sum_marks(data) 
{
    var sum = 0;
    data.forEach(element => {
        sum += parseInt(element['Marks']);
    });    
    return sum;
}
bubblesort = function (data) {
    var isSorted = false;
    while (!isSorted)
    {
        isSorted = true;
        for (let i = 0;i<data.length-1;i++)
        {
            if (parseInt(data[i]['Age']) > parseInt(data[i+1]['Age']))
            {
                var j = data[i+1];
                data[i+1] = data[i];
                data[i] = j;
                isSorted = false;
            }
        }
    }
    return data;
}
app.post("/sort",(req,res) => {
    res.json(bubblesort(req.body));
});

app.post("/sum",(req,res) => {
    var sum = sum_marks(req.body);
    res.send(`Sum of marks are ${sum}`);
});